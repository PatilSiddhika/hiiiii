﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelRequestManagement.Models;

namespace TravelRequestManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TblProjectsController : ControllerBase
    {
        private readonly TravelDbContext _context;

        public TblProjectsController(TravelDbContext context)
        {
            _context = context;
        }

        // GET: api/TblProjects
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TblProject>>> GetTblProjects()
        {
            return await _context.TblProjects.ToListAsync();
        }

        // GET: api/TblProjects/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TblProject>> GetTblProject(int id)
        {
            var tblProject = await _context.TblProjects.FindAsync(id);

            if (tblProject == null)
            {
                return NotFound();
            }

            return tblProject;
        }

        // PUT: api/TblProjects/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblProject(int id, TblProject tblProject)
        {
            if (id != tblProject.ProjectId)
            {
                return BadRequest();
            }

            _context.Entry(tblProject).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblProjectExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TblProjects
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<TblProject>> PostTblProject(TblProject tblProject)
        {
            _context.TblProjects.Add(tblProject);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (TblProjectExists(tblProject.ProjectId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetTblProject", new { id = tblProject.ProjectId }, tblProject);
        }

        // DELETE: api/TblProjects/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblProject(int id)
        {
            var tblProject = await _context.TblProjects.FindAsync(id);
            if (tblProject == null)
            {
                return NotFound();
            }

            _context.TblProjects.Remove(tblProject);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblProjectExists(int id)
        {
            return _context.TblProjects.Any(e => e.ProjectId == id);
        }
    }
}
