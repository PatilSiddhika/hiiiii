﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelRequestManagement.Models
{
    public partial class TblRequest
    {
        public TblRequest()
        {
            InverseEmp = new HashSet<TblRequest>();
            InverseProject = new HashSet<TblRequest>();
        }

        public int RequestId { get; set; }
        public string CauseTravel { get; set; }
        public string Source { get; set; }
        public int? Destination { get; set; }
        public string Mode { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? NoDays { get; set; }
        public string Priority { get; set; }
        public int? ProjectId { get; set; }
        public int? EmpId { get; set; }
        public string Status { get; set; }

        public virtual TblRequest Emp { get; set; }
        public virtual TblRequest Project { get; set; }
        public virtual ICollection<TblRequest> InverseEmp { get; set; }
        public virtual ICollection<TblRequest> InverseProject { get; set; }
    }
}
