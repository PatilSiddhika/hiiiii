﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelRequestManagement.Models
{
    public partial class TblRole
    {
        public int RoleId { get; set; }
        public string RoleType { get; set; }
    }
}
