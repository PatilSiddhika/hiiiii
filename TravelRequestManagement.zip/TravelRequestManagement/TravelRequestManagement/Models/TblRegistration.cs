﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelRequestManagement.Models
{
    public partial class TblRegistration
    {
        public TblRegistration()
        {
            InverseLIdNavigation = new HashSet<TblRegistration>();
            InverseRole = new HashSet<TblRegistration>();
        }

        public int EmpId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? Age { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public int? PhoneNo { get; set; }
        public int? LId { get; set; }
        public int? RoleId { get; set; }

        public virtual TblRegistration LIdNavigation { get; set; }
        public virtual TblRegistration Role { get; set; }
        public virtual ICollection<TblRegistration> InverseLIdNavigation { get; set; }
        public virtual ICollection<TblRegistration> InverseRole { get; set; }
    }
}
