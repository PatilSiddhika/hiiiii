using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain_Layer.Models;

namespace Domain_Layer.Entity_Mapper
{
  public class RoleMap : IEntityTypeConfiguration<Role>
  {
    public void Configure(EntityTypeBuilder<Role> builder)
    {
      builder.HasKey(e => e.RoleId)
         .HasName("role_id");

      builder.Property(e => e.RoleType)
          .IsRequired()
          .HasMaxLength(50)
          .HasColumnName("role_type");
    }
  }
}
