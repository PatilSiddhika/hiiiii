using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain_Layer.Models;

namespace Domain_Layer.Entity_Mapper
{
  public class LoginMap : IEntityTypeConfiguration<Login>
  {
    public void Configure(EntityTypeBuilder<Login> builder)
    {
      builder.HasKey(x => x.login_Id)
          .HasName("pk_l_id");


      builder.Property(x => x.UserName)
          .HasColumnName("Username")
          .HasColumnType("Varchar(50)")
          .IsRequired();
      builder.Property(x => x.Password)
          .HasColumnName("Password")
          .HasColumnType("Varchar(50)")

          .IsRequired();
      builder.Property(x => x.UserType)
           .HasColumnName("UserType")
           .HasColumnType("Varchar(50)")
           .IsRequired();
    }
  }
}
