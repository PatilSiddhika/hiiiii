using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.Models
{
  public partial class Request : BaseEntity
  {
    public Request()
    {
      Registration = new HashSet<Registration>();
      Projects = new HashSet<Project>();
    }
    public int request_Id { get; set; }
    public string CauseTravel { get; set; }
    public string Source { get; set; }
    public string Destination { get; set; }
    public string Mode { get; set; }
    public DateTime FromDate { get; set; }

    public DateTime ToDate { get; set; }
    public int NoDays { get; set; }
    public string Priority { get; set; }
    public string Status { get; set; }

    public virtual ICollection<Registration> Registration { get; set; }
    public virtual ICollection<Project> Projects { get; set; }
    public object EmpId { get; internal set; }
  }
}
