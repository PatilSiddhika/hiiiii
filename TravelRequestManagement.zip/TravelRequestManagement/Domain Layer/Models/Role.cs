using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.Models
{
  public partial class Role : BaseEntity
  {
    public Role()
    {
      Registrations = new HashSet<Registration>();
    }

    public int RoleId { get; set; }
    public string RoleType { get; set; }

    public virtual ICollection<Registration> Registrations { get; set; }
  }
}
